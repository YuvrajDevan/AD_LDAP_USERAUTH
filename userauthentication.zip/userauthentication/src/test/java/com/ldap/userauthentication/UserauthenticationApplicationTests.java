package com.ldap.userauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
