// auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


export interface DataResponse {
  key1: string;
  key2: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) { }


  
  login(samAccountName: string, password: string, basepath:string) {
    // Make a request to the API to authenticate the user
    const headers = { 'content-type': 'application/json',
                      // 'Access-Control-Allow-Origin': '*',
                      // 'Access-Control-Allow-Methods': "GET,POST,OPTIONS,DELETE,PUT"
                    }
    let obj = {samAccountName, password, basepath}
    return this.http.post<DataResponse>('http://localhost:8080/login', JSON.stringify(obj), {'headers':headers});
  }
}