import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {


  samAccountName: string ="";
  password: string = "";
  basepath: string = "";
  errorMessage: string = "";


  constructor(private authService: AuthService,  private router: Router) { }

  ngOnInit(): void {
  }
  
  onSubmit() {
    this.authService.login(this.samAccountName, this.password, this.basepath)
    .subscribe(
      (data) => {
        console.log("response" + JSON.stringify(data))
        const mapData = data as unknown as Map<string, any>;
        const values = Object.values(mapData);
        console.log(values)
        if(values[3]=="True"){
          window.alert("Authentication Details\n"
                       +"UID :"+values[0] +"\n"
                       +"DN :"+values[1] +"\n"
                       +"MESSAGE:"+values[2] +"\n"
                       +"STATUS :"+values[3] +"\n"
                       )
        }
        else{
          window.alert("Authentication Details\n"
          +"UID :"+values[0] +"\n"
          +"STATUS :"+values[1] +"\n"
          +"MESSAGE :"+values[2] +"\n"
          )
        }
      }
    );
} 
  }
